#ifndef __Lotery__
#define __Lotery__


#include "./Process.h"
#include "./SortingFunction.h"
#include "./PrintTable.h"


void lotery_print_gantt_chart(Process *p, int len) {
    //trabalhar na implementacao aqui
}

void Lotery(Process *p, int len) {
    //Trabalhar na implementação aqui
    printf("Necessario Implementar o Loteria");

}

#endif